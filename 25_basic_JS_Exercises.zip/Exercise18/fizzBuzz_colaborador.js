// Escreve um programa que imprima números de 1 a n. Para múltiplos de 3, imprima "Fizz" em vez do número, 
// e para múltiplos de 5, imprima "Buzz". Para números múltiplos de 3 e 5, imprima "FizzBuzz".

function fizzBuzz(n) {

}
  
fizzBuzz(15); 
//output:
//1
//2
//Fizz
//4
//Buzz
//Fizz
//7
//8
//Fizz
//Buzz
//11
//Fizz
//13
//14
//FizzBuzz