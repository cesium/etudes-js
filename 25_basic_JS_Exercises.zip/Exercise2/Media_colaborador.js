// Escreve uma função que calcule a média de uma sequência de números

function media(numero){

}

let numeros = [3, 5, 7, 2, 8];
console.log("Média:", media(numeros)); //output: 6
