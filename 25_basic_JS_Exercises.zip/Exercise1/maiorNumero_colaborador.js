//Escreve uma função que receba uma lista de números inteiros e retorna o maior número

function maiorNumero(lista) {

}


let numeros = [3, 5, 7, 2, 8];
console.log("Maior número:", maiorNumero(numeros));  //output: 8
