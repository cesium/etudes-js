function eAnagrama(str1, str2) {

}
  
console.log(eAnagrama("listen", "silent")); //output: true
console.log(eAnagrama("hello", "bello"));   //output:  false