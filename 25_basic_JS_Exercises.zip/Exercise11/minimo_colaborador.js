//Escreve uma função que encontre o menor número em um array de inteiros.

function minimoSimples(arr) {

}
  
  let numeros = [10, 5, 8, 1, 7];
  console.log("Menor número:", minimoSimples(numeros)); //output: 1 
  