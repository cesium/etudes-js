//Escreve uma função que verifique se uma palavra lida de trás para frente é igual à leitura normal.

function Palindromo(s) {

}
  
let palavra = "arara";
console.log("É palíndromo:", Palindromo(palavra)); //output: true