//Escreve uma função que remova todas as vogais de uma string

function removerVogais(s) {

}
  
let string = "exemplo";
console.log("String sem vogais:", removerVogais(string)); //output: xmpl