// Escreva uma função que junta duas strings.

function juntarStrings(s1,s2){

}

console.log("Strings juntas:", juntarStrings("Hello, ", "World!"));