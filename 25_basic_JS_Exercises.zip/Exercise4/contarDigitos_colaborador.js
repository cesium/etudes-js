// Escreve uma função que conte quantos dígitos um número inteiro possui

function contarDigitos(n){

}

console.log("Numero de digitos:", contarDigitos(440)); //output: 3  