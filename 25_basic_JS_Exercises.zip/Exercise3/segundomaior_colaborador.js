// Escreve uma função que encontre o segundo maior número em um array de inteiros

function segundoMaior(numeros){

}

let numeros = [3, 5, 7, 2, 8];
console.log("Segundo maior número:", segundoMaior(numeros)); //output: 7  