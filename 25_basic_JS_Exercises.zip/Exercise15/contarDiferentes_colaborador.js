// Escreve uma função que conte quantos caracteres únicos existem em uma string

function contarDiferentes(s) {

}
  
let stringDiferente = "aabbccdde";
console.log("Caracteres diferentes:", contarDiferentes(stringDiferente)); //output: 5