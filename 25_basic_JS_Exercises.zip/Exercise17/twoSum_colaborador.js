// Dado um array de inteiros nums e um inteiro target, retorne os índices de dois números no array 
// que somam o valor target.

function twoSum(nums, target) {

}
  
console.log(twoSum([2, 7, 11, 15], 9)); //output: [0, 1]