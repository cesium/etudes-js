 // Implementa uma função para ordenar um array de números em ordem crescente.

function ordenarArray(nums) {

}

console.log(ordenarArray([4, 2, 7, 1, 9])); //output: [1, 2, 4, 7, 9]  